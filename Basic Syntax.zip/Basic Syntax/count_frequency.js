const { ConstantColorFactor } = require("three");

let votes=["A","B","C","A","B","A","A"];

let count_a=0;
let count_b=0;
let count_c=0;

for (let char of votes){
    if (char ==="A"){
        count_a++;
    }
    else if (char ==="B"){
        count_b++;
    }
    else if(char ==="C"){
        count_c++;
    }
}


console.log(count_a);
console.log(count_b);
console.log(count_c);


if ((count_a > count_b) && (count_a > count_c)) {
    console.log("A is the winner");
} else if ((count_b > count_c) && (count_b > count_a)) {
    console.log("B is the winner");
} else {
    console.log("C is the winner");
}
