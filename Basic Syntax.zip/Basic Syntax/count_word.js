function count_word(txt) {
    // use built in method call split to split the word and store it in array call words then count the length of it 
    let words = txt.split(" "); 
    return words.length;
}

console.log(count_word("hello world"));        // Output: 2
console.log(count_word("hello world again"));  // Output: 3
