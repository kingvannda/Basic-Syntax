function countchar(txt,char){
    count=0;

    for (let i of txt){
        if (i===char){
            count++;
        }
        
    }
    return count;
}



console.log(countchar("hello world","z"));