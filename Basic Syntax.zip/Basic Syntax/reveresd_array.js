let arr=[1,2,3,4,5,6];
let temp_arr = [...arr]; //Using sperad operation to copy an array

let new_arr=[]

while (temp_arr.length>0){
    new_arr.push(temp_arr.pop());
}

console.log(arr);

console.log(new_arr);