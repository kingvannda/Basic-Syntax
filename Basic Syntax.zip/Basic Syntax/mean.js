let arr=[1,2,3,4,5,6];

if (arr.length===0){
    console.log(0);

}
sum=0;
for (let i of arr){
    sum+=i;
}

console.log("The average is: ",sum/arr.length);
